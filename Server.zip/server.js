// server.js

import express from 'express';
import mongoose from 'mongoose';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import ejs from 'ejs';
import cors from 'cors';
import path from 'path';
import cookieParser from 'cookie-parser';

dotenv.config();

// Initialize App
const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(express.json());
app.use(cors());
app.use(cookieParser());
app.use(express.static("./public"));
app.set("views", "./views");
app.set("view engine", "ejs");

// MongoDB Connection
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected'))
.catch((err) => console.error('MongoDB connection failed:', err));

// Schemas
const { Schema } = mongoose;

const userSchema = new Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    linkAuthor: [{ type: Schema.Types.ObjectId, ref: 'Link' }]
});

const linkSchema = new Schema({
    title: { type: String, required: true },
    url: { type: String, required: true },
    tags: { type: [String], required: true },
    category: { type: String, enum: ['Website Link', 'Social Media'], required: true }
}, { timestamps: true });

const User = mongoose.model('User', userSchema);
const Link = mongoose.model('Link', linkSchema);

// Middleware to Authenticate Token
const authenticateToken = (req, res, next) => {
    const token = req.cookies.token;
    if (!token) return res.render("login");

    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
        if (err) return res.status(403).json({ message: "Invalid Token" });

        req.user = decoded;
        next();
    });
};

// Routes

// Page Routes
app.get("/", (req, res) => res.render('landing'));
app.get("/signup", (req, res) => res.render('signup'));
app.get("/login", (req, res) => res.render('login'));
app.get("/about", (req, res) => res.render('about'));
app.get("/contact", (req, res) => res.render('contact'));
app.get("/privacy", (req, res) => res.render('privacy'));

// Authentication Routes
app.post('/signup', async (req, res) => {
    const { email, password } = req.body;
    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) return res.status(400).json({ message: 'User already exists' });

        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = await User.create({ email, password: hashedPassword });

        const token = jwt.sign({ userId: newUser._id }, process.env.JWT_SECRET, { expiresIn: '2h' });
        res.status(201).json({ message: 'User created successfully', token });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email });
        if (!user) return res.status(400).json({ message: 'Invalid credentials' });

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(400).json({ message: 'Invalid credentials' });

        const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '2h' });
        res.cookie("token", token, {
            httpOnly: true,
            secure: false, // set to true if using HTTPS
            maxAge: 2 * 60 * 60 * 1000 // 2 hours
        });

        res.status(200).json({ message: 'Login successful', token });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

app.get('/logout', (req, res) => {
    res.clearCookie('token');
    res.redirect('/login');
});

// Home (Authenticated)
app.get('/home', authenticateToken, async (req, res) => {
    try {
        const user = await User.findById(req.user.userId).populate('linkAuthor');
        res.render('home', { links: user.linkAuthor, username: user.email });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching links' });
    }
});

// Link Management API
app.post('/api/links', authenticateToken, async (req, res) => {
    try {
        const { title, url, tags, category } = req.body;
        const newLink = await Link.create({ title, url, tags, category });

        await User.findByIdAndUpdate(req.user.userId, { $push: { linkAuthor: newLink._id } });
        res.status(201).json({ success: true, message: "Link saved successfully" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: "Something went wrong" });
    }
});

app.get('/api/links/:id', async (req, res) => {
    try {
        const link = await Link.findById(req.params.id);
        if (!link) return res.status(404).json({ message: 'Link not found' });

        res.json(link);
    } catch (error) {
        console.error(error);
        res.status(400).json({ message: 'Invalid ID format' });
    }
});

app.delete('/api/links/:id', async (req, res) => {
    try {
        const deletedLink = await Link.findByIdAndDelete(req.params.id);
        if (!deletedLink) return res.status(404).json({ message: 'Link not found' });

        res.status(200).json({ message: 'Link deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(400).json({ message: 'Invalid ID format' });
    }
});

app.put('/api/links/:id', async (req, res) => {
    const { title, url, tags, category } = req.body;
    try {
        const updatedLink = await Link.findByIdAndUpdate(req.params.id, { title, url, tags, category }, { new: true, runValidators: true });
        if (!updatedLink) return res.status(404).json({ message: 'Link not found' });

        res.status(200).json(updatedLink);
    } catch (error) {
        console.error('Error updating link:', error);
        res.status(500).json({ message: 'Server error while updating link' });
    }
});

// Search API
app.post('/api/search', authenticateToken, async (req, res) => {
    const { query } = req.body;
    if (!query) return res.status(400).json({ message: 'Search query is required' });

    try {
        const searchQuery = {
            $or: [
                { title: { $regex: query, $options: 'i' } },
                { tags: { $regex: query, $options: 'i' } },
                { category: { $regex: query, $options: 'i' } }
            ]
        };
        const links = await Link.find(searchQuery);

        if (!links.length) return res.status(404).json({ message: 'No links found' });

        res.status(200).json({ message: 'Links found', links });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error while searching for links' });
    }
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
